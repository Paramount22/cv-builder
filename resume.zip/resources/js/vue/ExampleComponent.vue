<template>
    <h2 class="text-success">Hello Vue</h2>
</template>

<script>
    export default {
        name: "ExampleComponent",

        mounted() {
            console.log('Mounted');
        }
    }
</script>

<style scoped>

</style>
