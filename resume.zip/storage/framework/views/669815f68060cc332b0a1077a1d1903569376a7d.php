<?php $__env->startSection('content'); ?>
    <h2 class="text-white">Admin panel</h2>

    <div class="mt-4">
        <a class="btn btn-lg btn-outline-info" href="<?php echo e(route('levels.index')); ?>">Úrovne</a>
        <a class="btn btn-lg btn-outline-info" href="">Skupiny</a>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cvBuilder\resources\views/admin/home/index.blade.php ENDPATH**/ ?>