<?php $__env->startSection('content'); ?>
<div class="container">
    <h2 class="text-white mb-4">Úrovne</h2>
    <div class="col-md-4">
        <ul class="list-group">
            <?php $__currentLoopData = $levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="list-group-item"><?php echo e($level->name); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <a class="btn btn-sm btn-outline-secondary mt-4" href="<?php echo e(route('admin.index')); ?>">Späť</a>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cvBuilder\resources\views/admin/levels/index.blade.php ENDPATH**/ ?>