<nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm">
    <div class="container">
        <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
            <?php echo e(config('app.name', 'Laravel')); ?>

        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <!-- Left Side Of Navbar -->
            <ul class="navbar-nav mr-auto">
                <?php if(auth()->guard()->check()): ?>
                    <li>
                        <!-- Button trigger modal -->
                        <a href="" class="btn btn-outline-warning" data-toggle="modal" data-target="#resumeModal">
                            <i class="fas fa-eye"></i>   Náhľad CV
                        </a>
                    </li>
                <?php endif; ?>
            </ul>

            <!-- Modal -->
            <div class="modal fade" id="resumeModal" tabindex="-1" aria-labelledby="exampleModalLabel"
                 aria-hidden="true">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Náhľad</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <iframe src="<?php echo e(route('resume.index')); ?>" width="100%" height="900"></iframe>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Zavrieť</button>
                            <a href="<?php echo e(route('resume.download')); ?>" class="btn btn-danger">
                                <i class="fas fa-download"></i>  Uložiť ako pdf
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Right Side Of Navbar -->
            <ul class="navbar-nav ml-auto">
                <!-- Authentication Links -->
                <?php if(auth()->guard()->guest()): ?>
                    <?php if(Route::has('login')): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Prihlásenie')); ?></a>
                        </li>
                    <?php endif; ?>

                    <?php if(Route::has('register')): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Registrácia')); ?></a>
                        </li>
                    <?php endif; ?>
                <?php else: ?>
                    <li class="nav-item dropdown">
                        <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                            <?php echo e(Auth::user()->email); ?>

                        </a>

                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('has_access')): ?>
                                <a class="dropdown-item" href="<?php echo e(route('admin.index')); ?>">
                                    <i class="fas fa-user-shield"></i>  <?php echo e(__('Admin')); ?>

                                </a>
                            <?php endif; ?>

                            <?php if(auth()->user()->userDetail): ?>
                                <a class="dropdown-item" href="<?php echo e(route('user-details.index')); ?>">
                                    <i class="fas fa-user"></i>  <?php echo e(__('CV Profil')); ?>

                                </a>
                            <?php endif; ?>
                                <a class="dropdown-item" href="<?php echo e(route('user.edit', auth()->id())); ?>">
                                    <i class="fas fa-unlock"></i>  <?php echo e(__('Zmena údajov')); ?>

                                </a>

                            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                               onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                <i class="fas fa-sign-out-alt"></i>  <?php echo e(__('Odhlásiť sa')); ?>

                            </a>

                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                <?php echo csrf_field(); ?>
                            </form>
                        </div>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>
<?php /**PATH C:\xampp\htdocs\cvBuilder\resources\views/layouts/navigation.blade.php ENDPATH**/ ?>