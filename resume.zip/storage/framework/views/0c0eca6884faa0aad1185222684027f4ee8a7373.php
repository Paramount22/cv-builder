<?php $__env->startSection('content'); ?>
    <section class="home">
        <h2 class="text-dark">Životopis</h2>

        <?php if(auth()->user()): ?>
            <?php if( auth()->user()->userDetail): ?>
                <span>
                <a class="btn btn-lg btn-outline-warning shadow" href="<?php echo e(route('user-details.index')); ?>">
                    Môj profil
                </a>
            </span>
            <?php endif; ?>

        <?php else: ?>
            <span>
                <a class="btn btn-lg btn-outline-primary" href="<?php echo e(route('user-details.create')); ?>">Vytvor si svoj životopis</a>
            </span>
        <?php endif; ?>

        <?php if(auth()->user()): ?>
            <?php if(!auth()->user()->userDetail): ?>
                <span>
                <a class="btn btn-lg btn-outline-primary" href="<?php echo e(route('user-details.create')); ?>">Vytvor si svoj životopis</a>
            </span>
            <?php endif; ?>
        <?php endif; ?>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cvBuilder\resources\views/home/index.blade.php ENDPATH**/ ?>