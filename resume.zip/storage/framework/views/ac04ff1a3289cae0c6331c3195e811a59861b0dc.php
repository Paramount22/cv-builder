<?php $__env->startSection('content'); ?>

    <section class="education">

        <div class="row justify-content-center">
            <div class="col-md-8 d-flex justify-content-between align-items-center mb-4">
                <h2 class=" text-dark">Vzdelanie</h2>
                <span>
                    <a href="<?php echo e(route('education.create')); ?>">
                        <button class="btn btn-sm btn-outline-dark">
                          <i class="fas fa-plus mr-1"></i>  Pridať vzdelanie
                        </button>
                    </a>
                </span>
            </div>
        </div>
        <div class="row justify-content-center">
            <div class="col-md-8">
                <?php echo $__env->make('_partials.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php $__empty_1 = true; $__currentLoopData = $education; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="card shadow-sm mb-3">
                    <div class="card-body">
                        <div class="d-flex justify-content-between">
                            <h4 class="card-title text-dark"><?php echo e($e->school_name); ?></h4>

                            <span class="edit-links">
                                <a class="text-danger" href="" data-toggle="modal"
                                   data-target="#editEducation-<?php echo e($e->id); ?>">
                                    <i class="fas fa-pencil-alt"></i>
                                </a>

                                 <a class="text-danger" href="" data-toggle="modal"
                                    data-target="#deleteEducation-<?php echo e($e->id); ?>">
                                    <i class="fas fa-trash"></i>
                                </a>

                            </span>
                        </div>

                        <p class="card-text">
                            <?php echo e($e->FullFormatDate); ?>,  <?php echo e($e->city); ?>

                        </p>

                        <?php if($e->field_of_study): ?>
                            <p class="card-text">
                                <?php echo e($e->field_of_study); ?>

                            </p>
                        <?php endif; ?>
                        <?php if($e->description): ?>
                            <p class="card-text">
                                <?php echo nl2br($e->description); ?>

                            </p>
                         <?php endif; ?>

                    </div>
                </div>

                    <!-- Modal -->
                    <div class="modal fade" id="editEducation-<?php echo e($e->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-lg">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title text-dark" id="exampleModalLabel">Upraviť údaje</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <form action="<?php echo e(route('education.update', $e)); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('put'); ?>
                                        <?php echo $__env->make('_partials.educationForm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        <button class="btn btn-primary">Uložiť zmeny</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Modal delete education -->
                    <div class="modal fade" id="deleteEducation-<?php echo e($e->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title text-dark" id="exampleModalLabel">Si si istý ?</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    Záznan bude vymazaný.
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                    <form action="<?php echo e(route('education.destroy', $e)); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        <button type="submit" class="btn btn-danger">Vymazať</button>
                                    </form>

                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="alert alert-warning" role="alert">
                        Momentálne neevidujeme žiadne vzdelanie.
                    </div>

                <?php endif; ?>
            </div>

        </div>

        <div class="row justify-content-center">
            <div class="col-8 d-flex justify-content-end">
                <?php if(auth()->user()->works->count()): ?>
                    <a class="btn btn-outline-dark" href="<?php echo e(route('works.index')); ?>">
                        Pokračovať na pracovné skúsenosti
                    </a>
                <?php else: ?>
                    <a class="btn btn-outline-dark" href="<?php echo e(route('works.create')); ?>">
                        Pokračovať na pracovné skúsenosti
                    </a>
                <?php endif; ?>

            </div>
        </div>

    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cvBuilder\resources\views/education/index.blade.php ENDPATH**/ ?>