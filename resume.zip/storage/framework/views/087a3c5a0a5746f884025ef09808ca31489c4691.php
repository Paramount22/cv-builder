<?php if(auth()->guard()->check()): ?>
    <?php if(auth()->user()->userDetail): ?>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                    <li class="breadcrumb-item <?php echo e(request()->is('user-details') ? 'active' : ''); ?>">
                        <a class="text-dark" href="<?php echo e(route('user-details.index')); ?>">
                            Základné údaje
                        </a>
                    </li>


                <li class="breadcrumb-item <?php echo e(request()->is('education') ? 'active' : ''); ?>">
                    <a class="text-dark" href="<?php echo e(route('education.index')); ?>">
                        Vzdelanie
                    </a>
                </li>

                <li class="breadcrumb-item <?php echo e(request()->is('works') ? 'active' : ''); ?>">
                    <a class="text-dark" href="<?php echo e(route('works.index')); ?>">
                        Pracovné skúsenosti
                    </a>
                </li>

                <li class="breadcrumb-item <?php echo e(request()->is('courses') ? 'active' : ''); ?>">
                    <a class="text-dark" href="<?php echo e(route('courses.index')); ?>">
                        Kurzy
                    </a>
                </li>

                <li class="breadcrumb-item <?php echo e(request()->is('skills') ? 'active' : ''); ?>">
                    <a class="text-dark" href="<?php echo e(route('skills.index')); ?>">
                        Znalosti
                    </a>
                </li>

                <li class="breadcrumb-item <?php echo e(request()->is('languages') ? 'active' : ''); ?>">
                    <a class="text-dark" href="<?php echo e(route('languages.index')); ?>">
                        Jazyky
                    </a>
                </li>

                <li class="breadcrumb-item <?php echo e(request()->is('hobby') ? 'active' : ''); ?>">
                    <a class="text-dark" href="<?php echo e(route('hobby.index')); ?>">
                        Záujmy alebo koníčky
                    </a>
                </li>

            </ol>
        </nav>
    <?php endif; ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\cvBuilder\resources\views/layouts/breadcrumb.blade.php ENDPATH**/ ?>