<!doctype html>
<html lang="sk">
<head>
    <!-- Required meta tags -->
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Resume</title>
</head>
<style>
    body {
        font-family: sans-serif;

    }

    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }

    .container {
        max-width: 1024px;
        margin: 0 auto;
        padding: .5rem 2rem;
    }

    .user-info {
        margin-top: 3rem;
        margin-bottom: 3rem;
    }
    .user-info p {
        margin-bottom: .3rem;

    }

    .full-name {
        color: #175f73;
        font-size: 2rem;
        margin-bottom: 1rem;
    }

    .user-works,
    .user-education,
    .user-courses,
    .user-skills,
    .user-languages,
    .user-hobby {
        margin-bottom: 3rem;
    }

    h3 {
        color: #175f73;
        border-bottom: 2px solid #175f73;
        padding-bottom: .3rem;
        text-transform: uppercase;
    }

    h4 {
        margin-bottom: .3rem;
        margin-top: 1rem;


    }

    .user-works p,
    .user-education p,
    .user-courses p,
    .user-skills p,
    .user-languages p,
    .user-hobby p {
        margin-bottom: .2rem;
        font-size: .8rem;

    }

    .user-skills p,
    .user-languages p,
    .user-hobby p {
        margin-top: .5rem;
    }

    small {
        font-size: 80%;
    }

</style>
<body class="container">

        <section class="user-info">
            <?php if($user->userDetail): ?>
                <h1 class="full-name">
                    <?php echo e($user->userDetail->fullName); ?>

                </h1>
                <p><strong>Adresa:</strong> <?php echo e($user->userDetail->fullAddress); ?> </p>
                <p><strong>Tel.:</strong> <?php echo e($user->userDetail->phone); ?> </p>
                <p><strong>Email:</strong> <?php echo e($user->email); ?> </p>
                <p><strong>Dátum narodenia:</strong> <?php echo e(date("j. n. Y",  strtotime($user->userDetail->birthdate) )); ?> </p>
             <?php endif; ?>
        </section>

        <?php if(isset($user->works)): ?>
            <section class="user-works">
                <h3>PRACOVNÉ SKÚSENOSTI</h3>
                <?php $__currentLoopData = $user->works; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $work): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <h4> <?php echo e($work->employer); ?></h4>
                    <p> <?php echo e($work->job_title); ?>  </p>
                    <p>
                        <?php echo e($work->StartFormatDate); ?> -
                        <?php if($work->EndFormatDate == 1970): ?>
                            Doteraz,
                        <?php else: ?>
                            <?php echo e($work->EndFormatDate); ?>,
                        <?php endif; ?>
                        <?php echo e($work->city); ?>

                    </p>
                    <p>
                        <?php if($work->description): ?>
                            <small><?php echo nl2br($work->description); ?></small>
                        <?php endif; ?>
                    </p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </section>
        <?php endif; ?>

        <?php if(isset($user->education)): ?>
            <section class="user-education">
                <h3>Vzdelanie</h3>
                    <?php $__currentLoopData = $user->education; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $education): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <h4> <?php echo e($education->school_name); ?></h4>
                        <p> <?php echo e($education->field_of_study); ?> </p>
                        <p> <?php echo e($education->FullFormatDate); ?>, <?php echo e($education->city); ?> </p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </section>
        <?php endif; ?>

        <?php if(isset($user->courses)): ?>
            <section class="user-courses">
                <h3>Kurz alebo certifikát </h3>
                <?php $__currentLoopData = $user->courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <h4><?php echo e($course->institution); ?></h4>
                    <p><?php echo e($course->title); ?>, <?php echo e($course->FullFormatDate); ?></p>
                    <p><?php echo e($course->description); ?></p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </section>
        <?php endif; ?>

        <?php if(isset($user->skills)): ?>
            <section class="user-skills">
                <h3>Znalosti </h3>
                    <?php $__currentLoopData = $user->skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p> <strong><?php echo e($skill->name); ?></strong>  - <?php echo e($skill->level->name); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </section>
        <?php endif; ?>

        <?php if(isset($user->languages)): ?>
            <section class="user-languages">
                <h3>Jazyky</h3>
                <?php $__currentLoopData = $user->languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p> <strong><?php echo e($language->language); ?></strong>  - <?php echo e($language->languageLevel->name); ?></p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </section>
        <?php endif; ?>

        <?php if( isset($user->userDetail->drivingLicenses) ): ?>
            <section class="user-languages">
                <h3>Vodičský preukaz</h3>
                <?php $__currentLoopData = $user->userDetail->drivingLicenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $license): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p> <strong><?php echo e($license->group); ?> </strong> </p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </section>
        <?php endif; ?>

        <?php if(isset($user->hobby)): ?>
            <section class="user-hobby">
                <h3>Záujmy alebo koníčky</h3>
                    <p> <?php echo e($user->hobby->text); ?>  </p>
            </section>
        <?php endif; ?>


</body>
</html>
<?php /**PATH C:\xampp\htdocs\cvBuilder\resources\views/resume/index.blade.php ENDPATH**/ ?>