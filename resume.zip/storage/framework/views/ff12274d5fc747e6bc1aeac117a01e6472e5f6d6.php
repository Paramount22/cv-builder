<?php $__env->startSection('content'); ?>
    <section class="user-detail">
        <div class="row justify-content-center mb-4">
            <div class="col-8">
                <h2 class="text-dark ">Základné údaje</h2>
            </div>

        </div>
        <div class="row justify-content-center">
            <div class="col-md-8">
                <?php echo $__env->make('_partials.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="card shadow">
                    <div class="card-body">
                        <div class="d-flex justify-content-between mb-2">
                            <h4 class="card-title text-dark"><?php echo e($userDetail->fullName); ?></h4>
                            <span>
                                <a class="text-danger" href="" data-toggle="modal"
                                   data-target="#editUserModal-<?php echo e($userDetail->id); ?>">Upraviť</a>
                            </span>
                        </div>

                        <h6 class="card-subtitle mb-4 text-muted"><?php echo e($userDetail->formatDate); ?></h6>
                        <h5 class="text-dark mb-3"> Kontaktné údaje </h5>
                        <p class="card-text">
                            <i class="far fa-envelope"></i>
                           <strong>E-mailová adresa:</strong>  <?php echo e(auth()->user()->email); ?>

                        </p>

                        <p class="card-text">
                            <i class="fas fa-phone-alt"></i>
                            <strong>Telefónne číslo:</strong> <?php echo e($userDetail->phone); ?>

                        </p>

                        <p class="card-text">
                            <i class="fas fa-home"></i>
                            <strong>Adresa:</strong> <?php echo e($userDetail->fullAddress); ?>

                        </p>
                        <p class="card-text mb-3">
                            <i class="far fa-address-card"></i>
                           <strong>Vodičský preukaz:</strong>
                            <?php if($userDetail->drivingLicenses): ?>
                                <?php $__currentLoopData = $userDetail->drivingLicenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span class="badge badge-success"><?php echo e($group->group); ?></span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </p>
                        <?php if(  auth()->user()->education->count() ): ?>
                            <span class="d-flex justify-content-end">
                                <a class="btn btn-outline-dark" href="<?php echo e(route('education.index')); ?>">
                                    Pokračovať na vzdelanie
                                </a>
                            </span>
                        <?php else: ?>
                            <span class="d-flex justify-content-end">
                                <a class="btn btn-outline-dark" href="<?php echo e(route('education.create')); ?>">
                                    Pokračovať na vzdelanie
                                </a>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Modal -->
    <div class="modal fade" id="editUserModal-<?php echo e($userDetail->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title text-dark" id="exampleModalLabel">Upraviť údaje</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('user-details.update', $userDetail)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('put'); ?>
                        <?php echo $__env->make('_partials.userDetailForm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="row">
                            <div class="col-md-8">
                                <div class="card edit-license-group mb-3">
                                    <div class="card-header">
                                        <h6 class="mb-0">
                                            Vodičský preukaz
                                        </h6>
                                    </div>
                                    <ul class="list-group">
                                        <?php if(isset($drivingLicense)): ?>
                                            <?php $__currentLoopData = $drivingLicense; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $license): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li class="list-group-item d-flex justify-content-between">
                                                    <div class="form-check d-flex align-items-center">
                                                        <input class="form-check-input" type="checkbox"
                                                               name="driving_licenses[]"
                                                               value="<?php echo e($license->id); ?>"
                                                               id="<?php echo e($license->group); ?>"
                                                            <?php echo e(($userDetail->drivingLicenses()->pluck('id')->contains($license->id)) ? 'checked' : ''); ?>

                                                        >

                                                        <label class="form-check-label ml-2 label-text-group" for="<?php echo e($license->group); ?>">
                                                            <?php echo e($license->group); ?>

                                                        </label>
                                                    </div>

                                                   <?php if($license->id === 1): ?>
                                                        <span>
                                                            <i class="fas fa-motorcycle"></i>
                                                        </span>
                                                    <?php endif; ?>
                                                    <?php if($license->id === 2): ?>
                                                        <span>
                                                            <i class="fas fa-car"></i>
                                                        </span>
                                                    <?php endif; ?>
                                                    <?php if($license->id === 3): ?>
                                                        <span>
                                                            <i class="fas fa-truck"></i>
                                                        </span>
                                                    <?php endif; ?>
                                                    <?php if($license->id === 4): ?>
                                                        <span>
                                                            <i class="fas fa-bus"></i>
                                                        </span>
                                                    <?php endif; ?>
                                                    <?php if($license->id === 5): ?>
                                                        <span>
                                                            <i class="fas fa-truck-moving"></i>
                                                        </span>
                                                    <?php endif; ?>
                                                    <?php if($license->id === 6): ?>
                                                        <span>
                                                            <i class="fas fa-tractor"></i>
                                                        </span>
                                                    <?php endif; ?>
                                                </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>

                                    </ul>
                                </div>
                            </div>

                        </div>
                        <div class="form-group">
                            <button class="btn btn-primary">Uložiť zmeny</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cvBuilder\resources\views/userdetails/index.blade.php ENDPATH**/ ?>