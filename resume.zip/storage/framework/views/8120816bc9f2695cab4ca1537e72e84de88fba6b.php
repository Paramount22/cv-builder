<?php $__env->startSection('content'); ?>

    <div class="row justify-content-center ">

        <div class="col-md-10 mt-3">
            <?php echo $__env->make('_partials.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Vzdelanie</h6>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('education.store')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo $__env->make('_partials.educationForm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        <div class="form-group">
                            <button class="btn btn-primary">Uložiť a pokračovať</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cvBuilder\resources\views/education/create.blade.php ENDPATH**/ ?>